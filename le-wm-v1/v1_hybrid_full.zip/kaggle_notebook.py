"""
# V1: Hybrid CfC+Attention — TwoRoom benchmark
# Copy toàn bộ cell này vào Kaggle notebook, run từng cell.
"""

# %% Cell 1: Install + login
!pip install stable-worldmodel[train,env] ncps h5py hdf5plugin huggingface_hub --quiet
from huggingface_hub import login, HfApi
login(token="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")

# %% Cell 2: Check GPU
import torch, subprocess
print(torch.cuda.get_device_name(0), "| VRAM:", round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1), "GB")
!nvidia-smi | head -5

# %% Cell 3: Setup env + clone LeWM
import os
os.environ["STABLEWM_HOME"] = "/kaggle/working"
os.environ["LOCAL_DATASET_DIR"] = "/kaggle/working"
!git clone https://github.com/lucas-maes/le-wm.git /kaggle/working/le-wm

# %% Cell 4: Paste module.py content ở đây (mở module.py trong D:\ai_training\le-wm-v1\ rồi copy vào)
# Sau đó: chạy:
!mkdir -p /kaggle/working/le-wm/config/train/model/
# Copy các file từ workspace vào LeWM (upload thủ công vào Kaggle)
# Hoặc paste trực tiếp vào /kaggle/working/le-wm/module.py

# %% Cell 5: Override config cho Hybrid
# Thay config/train/model/lewm.yaml và config/train/lewm.yaml bằng bản Hybrid
# Config content:
# - model/hybrid.yaml: _target_: module.HybridCfCPredictor
# - lewm_hybrid.yaml: defaults model: hybrid, max_epochs: 10

# %% Cell 6: Download TwoRoom data (~3.4GB)
from huggingface_hub import snapshot_download
snapshot_download("quentinll/lewm-tworooms", repo_type="dataset", local_dir="/kaggle/working/tworoom_data")
!tar --zstd -xvf /kaggle/working/tworoom_data/tworoom.tar.zst -C /kaggle/working/

# %% Cell 7: Train Hybrid (10 epochs, ~30-45ph on A100)
!cd /kaggle/working/le-wm && python train.py --config-name=lewm_hybrid data=tworoom

# %% Cell 8: Upload checkpoint to HF
import os
api = HfApi()
ckpt_dir = "/kaggle/working/checkpoints/lewm_hybrid"
if os.path.exists(ckpt_dir):
    api.upload_folder(folder_path=ckpt_dir, repo_id="hilobaby/checkpoitn",
                      repo_type="model", commit_message="Hybrid TwoRoom done")

# %% Cell 9: Eval after training (optional)
# !cd /kaggle/working/le-wm && python eval.py --config-name=tworoom policy=tworoom/lewm
